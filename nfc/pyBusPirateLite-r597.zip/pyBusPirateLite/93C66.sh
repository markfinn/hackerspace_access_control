#!/usr/bin/env bash

python -u ./MicroWire.py -d /dev/ttyUSB0 -n 4096 -o 8 -f output.dat -v -c 8
